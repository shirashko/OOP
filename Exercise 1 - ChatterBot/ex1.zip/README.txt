shirashko
209144013

Shir: hello is an illegal request.
Adi: hello is an illegal request. is not a valid request.
Shir: You're not following my instructions with telling me hello is an illegal request. is not a valid request.
Adi: Why, oh why, are you making an illegal request?
Shir: Why, oh why, are you making an illegal request? is an illegal request.
Adi: Why, oh why, are you making an illegal request? is an illegal request. is not a valid request.
Shir: You're not following my instructions with telling me Why, oh why, are you making an illegal request? is an illegal request. is not a valid request.
Adi: Why, oh why, are you making an illegal request?
Shir: You're not following my instructions with telling me Why, oh why, are you making an illegal request?
Adi: Why, oh why, are you making an illegal request?
Shir: say say what you want to say
Adi: Sure, here it goes: say what you want to say
Shir: say say what you want to say
Adi: Sure, here it goes: say what you want to say
Shir: You're not following my instructions with telling me Sure, here it goes: say what you want to say
Adi: Why, oh why, are you making an illegal request?
Shir: say say what you want to say
Adi: Sure, here it goes: say what you want to say
Shir: You're not following my instructions with telling me Sure, here it goes: say what you want to say
Adi: You're not following my instructions with telling me Sure, here it goes: say what you want to say is not a valid request.
Shir: You're not following my instructions with telling me Sure, here it goes: say what you want to say is not a valid request. is an illegal request.
Adi: You're not following my instructions with telling me Sure, here it goes: say what you want to say is not a valid request. is an illegal request. is not a valid request.
Shir: You're not following my instructions with telling me You're not following my instructions with telling me Sure, here it goes: say what you want to say is not a valid request. is an illegal request. is not a valid request.
Adi: say say statement
Shir: Of course, here's your request: say statement
Adi: Of course, here's your request: say statement is not a valid request.
Shir: Of course, here's your request: say statement is not a valid request. is an illegal request.
Adi: Of course, here's your request: say statement is not a valid request. is an illegal request. is a no-go zone.
Shir: You're not following my instructions with telling me Of course, here's your request: say statement is not a valid request. is an illegal request. is a no-go zone.
Adi: You're not following my instructions with telling me Of course, here's your request: say statement is not a valid request. is an illegal request. is a no-go zone. is not a valid request.
Shir: You're not following my instructions with telling me Of course, here's your request: say statement is not a valid request. is an illegal request. is a no-go zone. is not a valid request. is an illegal request.
Adi: You're not following my instructions with telling me Of course, here's your request: say statement is not a valid request. is an illegal request. is a no-go zone. is not a valid request. is an illegal request. is a no-go zone.
Shir: say say what you want to say
Adi: Sure, here it goes: say what you want to say
Shir: say say what you want to say
Adi: Alright, here's your request: say what you want to say
Shir: say say what you want to say
Adi: Alright, here's your request: say what you want to say
